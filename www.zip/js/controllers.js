angular.module('starter.controllers', [])

.controller('HomeCtrl', function($scope) {})

.controller('PhotoAlbumCtrl', function($scope) {});
